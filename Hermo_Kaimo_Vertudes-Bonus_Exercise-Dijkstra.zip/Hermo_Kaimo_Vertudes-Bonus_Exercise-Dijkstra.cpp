// Created by: Andrew Louis R. Hermo, Fourthram Kaimo, and Ron Bryan Vertudes University of the Philippines BS Computer Science December 24, 2020
// Bonus Programming Exercise: Dijkstra's Algorithm
#include <iostream>
#include <stdlib.h>
#include <vector>
#include <chrono>
#include <string>
#include <fstream>
#include <bits/stdc++.h>
#include <map>
#include <queue>
#include <algorithm>

using namespace std;
using namespace std::chrono;

class Elements{	// Class that is used when storing values in the Node Hash Map
	public:	//It serves as the elements when trying to access by node rather than label
		int adj;	// Stores the adjacent, or the end node indicated in the file
		float dist;	// Stores the distance indicated in the file
		string label;	// Stores the segment label indicated in the file
};

class Graph:public Elements{	// Class that is a child of Elements, which is the main class containing all constants
	unordered_multimap <int,Elements> node_map;	//	Unordered multimap/ Hash map that uses the start node as the key, and the elements as the values stored in class Elements
	// Format: Key = 1 (Starting node) | Element: { 2 (Ending/Adjacent node), 1 (Distance), matina-pangi (segment label)}
	unordered_multimap <string,pair<int,int>> label_map;	// Hash map that stores the segment label as the key, and the elements as the two nodes connected by the segment
	// Format: Key = matina-pangi (segment label) | < 1 , 2 > (Two nodes that the segment connects)
	float travel_speed=40;	// Travel speed constant in KPH
	float fdown_rate=40;	//Flag down rate constant
	float fare_per_min=2.50;	//	Fare per minute
	float taxi_fare=13;	//	Fate per kilometer

	void Input_data(string line);	// Private function that inputs the values from the file
	int FareCalc(float dis);	// Private function that calculates the fare of the trip
	public:
		void Input_file();	// Opens the file, then calls the Input_data function to store the values
		void Disp();	// Displays outputs
		void Dijkstra(string start, string end);	// Called when Dijkstra is needed to be performed
		void Check(string start, string end);	// Checks if the starting and/or ending points exist
};

class Table_Data{	// Class that is used when storing values in the Label Hash Map
	public:	// It serves as the elements when trying to access by segment label rather than nodes
		string prev;	// Stores the previous node
		float dist;	// Stores the distance travelled by the path
};

void Graph::Input_data(string line){	// Inputs the values into the Hash Maps
	string temp;	// Temporary storage variable for the string extracted from the file

	int i = 0;
	int node;	// Storage variable for the starting node
	int temp_adj;	// Storage variable for the adjacent node
	float temp_dist;	// Storage variable for the distance

	bool node_chk = false;	// Boolean for checking if the starting node has been extracted
	bool adj_chk = false;	// Boolean for checking if the end node has been extracted
	bool dist_chk = false;	// Boolean for checking if the distance has been extracted

	for(string::iterator it=line.begin();it!=line.end();it++,i++){	// Loops the entire line that has been extracted from the file
		/* Example: 1 2 1 matina-pangi
			Loops the string and stores every character then stops only if a space is met, or is at the end of the storing
			check 1
			store 1 to temp
			check 'space'
			initiate if statements
			clear temp_adj
			...
		*/
		if(*it==' '||i==line.size()){	// Checks if a space has been met or is at the end of the string
			if(!node_chk){	// Executes if the node has not been stored yet
				node = stoi(temp);	// Stores and converts the string to integer
				node_chk = true;	// Makes this if statement inaccessible
			}
			else if(!adj_chk){	// Executes if the adjacent has not been stored yet
				temp_adj = stoi(temp);	// Stores and converts the string to integer
				adj_chk=true;	// Makes this else if statement inaccessible
			}
			else if(!dist_chk){	// Executes if the distanced has not been stored yet
				temp_dist = stof(temp);	// Stores and converts the string to ineger
				dist_chk=true;	// Makes this else if statement inaccessible
			}
			else break;	// Stops the for loop if the iterator is at the end of the string
			temp.clear();	// Clears the temporary variable for storage of the next characters
		}
		else temp=temp+*it;	// Adds the current character to the temp string
	}

		Elements m;	// Initiates a class of Elements to be stored in the node Hash map
		m.adj=temp_adj;	// Stores the adjacent node in the class
		m.dist=temp_dist;	// Stores the distance in the class
		m.label=temp;	// Stores the label in the class
		node_map.insert(pair<int,Elements> (node,m));	// Uses the node as the key and the class as its elements
		/*	Example:
				Key		||		Adjacent node		Distance				Label
				1			||					2							1					matina-pangi
				2			||					3							2					matina-aplaya
												...
		*/


		m.adj=node;	// Stores the reverse of the starting and end node since the road is two way
		node_map.insert(pair<int,Elements> (temp_adj,m));
		/*	Example:
				Key		||		Adjacent node		Distance				Label
				1			||					2							1					matina-pangi
				2			||					1							1					matina-pangi
				2			||					3							2					matina-aplaya
				3			||					2							2					matina-aplaya
												...
		*/

		pair<int,int> a(node,temp_adj);	// Creates a pair that stores the two nodes connected by the segment
		// Note: Node 1 can be start or end node, since it is two-way. Same goes for node 2.
		/*	Example:
				Key								||			Node 1				Node 2
				matina-pangi			||				1							2
				matina-aplaya			||				2							3
												...
		*/
		label_map.insert(pair<string,pair<int,int>> (temp,a));
}

void Graph::Input_file(){
	string line;

	// Creation of ifstream class object to read the file
	ifstream fin;

	// by default open mode = ios::in mode
	fin.open("PEBonus_RoadNetwork.in");
	// Execute a loop until EOF (End of File)
	while (fin) {

		// Read a Line from File
		getline(fin, line);

		Input_data(line);
	}

	// Close the file
	fin.close();
}	// Opens the file and extracts each line

void Graph::Disp(){	// Displays every label segment along with the nodes it connects
	// Access the Label Hash Map then just displays every key along with its elements
	auto start = high_resolution_clock::now();	// Starts a clock that calculates the execution time
	for(auto i=label_map.begin();i!=label_map.end();i++) cout<<"Segment: "<<i->first<<"\nNode 1: "<<i->second.first<<"\nNode 2: "<<i->second.second<<endl;
	// Displays every key and element in Label Hash Map
	auto stop = high_resolution_clock::now();	// Stops the clock

	auto duration = duration_cast<microseconds>(stop - start);	// Calculates the execution time in microseconds
	auto seconds = duration_cast<milliseconds>(stop - start);	// Calculates the execution time in milliseconds
	cout << "\nTime taken by Display function using hash map: "<< duration.count() << " microseconds or "<<seconds.count()<<" milliseconds."<< endl;
	// Displays the execution time in microseconds and milliseconds
}

int Graph::FareCalc(float dis){	// Calculates the fare of the trip
	float time_elapsed=((int)dis/travel_speed)/60;
	/* Calculate the time with speed of 40 kph and the distance travelled
	Since there is no time given by the problem, we use the formula: Time = Distance / speed to get the time
	Also, since the travel speed is 40 kilometers per hour and the fare_per_minutes is 2.5 per minute
	We need to convert hour into minutes, so we divide it by 60
	Also convert the distance into integer for easier calculation
	*/
	int whole_km_fare=taxi_fare*(int)dis;
	// Calculate the fare per kilometer travelled: 2.5 * kilometer converted to integer
	return fdown_rate+(whole_km_fare)+(fare_per_min*time_elapsed);
	// Calculates then returns using the formula: 40+(13* km )+(2.5*((km/40)/60))
}

void Graph::Dijkstra(string start, string end){	// Performs Dijkstra's Algorithm
	vector<string> visited;	// Creates an array vector for the segments visited
	unordered_map<string,Table_Data> table;	// Creates a hash map as the storage of every segment accessed

	priority_queue<pair<float,string>, vector<pair<float,string>>, greater<pair<float,string>>> prio_q;
	// Creates a priority queue, which is essentially a Min Heap structure so that the least distance is always taken

	bool brk_flag=false;

	visited.push_back(start);	// Pushes the starting node to the visited nodes
	string curr = start;	// Sets the current node as the starting node
	auto start_loc = label_map.find(start);
	int fnow = start_loc->second.first;
	int fnext = start_loc->second.second;

	float val = 0;

	auto temp_ran = node_map.equal_range(fnow);
	for(auto i = temp_ran.first;i!=temp_ran.second;i++){
		if(i->second.adj == fnext) val = i->second.dist;	// Variable that stores the total distance travelled using that segment
	}
	float temp_val = 0;	// Variable that temporarily stores the distance travelled

	Table_Data temp;	// Initiates a class Table_Data with name temp
	temp.prev="SOURCE";	// Sets the previous as SOURCE as a way to create a stopping point when back-tracking
	temp.dist=val;	// Sets the current val as distance travelled
	table.insert(pair<string,Table_Data> (curr,temp));	// Insert to the table with key as the current segment label

	/* Example of the Table_Data table:
	Key						||		Prev				Dist
	matina-pangi	||	SOURCE				0
	matina-market	||	matina-pangi	0.1
	...
	*/

	while(curr!=end){	// Create a do-while loop that post-tests if the current label	== end label
		auto it = label_map.find(curr);	// Creates a iterator to the location of the current node in the Label Hash Map
		int now = it->second.first;
		int next = it->second.second;

		/*	Where now and next were taken:
				Key								||			Node 1				Node 2
				matina-pangi			||				1							2
				now = Node 1
				next = Node 2
		*/

		auto j = node_map.equal_range(next);	// Finds all keys in the Node Hash Map with the key in node 2
		for(auto i=j.first;i!=j.second;i++){	// Iterates to all the keys taken from iterator j
			temp_val=val;	// Set this temp_val as the current value always
			string next_label = i->second.label;	// Gets the label of the current adjacent node

			if(next_label == end){ // If the next label is the last node stop the loop
				temp.prev=curr;	// Insert the prev node passed by the node as the curr
				temp.dist=temp_val;	// No changes to the distance
				table.insert(pair<string,Table_Data> (next_label,temp));
				brk_flag = true;	// Flag that stops the loop if the end is found
				break;
			}

			temp_val+= (float)i->second.dist;	// Take the distance of that segment and add it to the temp_val *****
			if(!(std::find(visited.begin(), visited.end(), next_label) != visited.end())){	// Checks if the node doesn't exist in the visited vector
				auto new_entry = table.find(next_label);	// Creates a pointer to the location of the segment label in the Table_Data table
				if(new_entry!=table.end()){	// If the segment exists in the Table_Data proceed
					float existing_dist = new_entry->second.dist;	// Create a copy of the current distance of the segment label
					if(temp_val>=existing_dist) continue;	// If the distance to be added is greater or equal than the existing distance, skip and continue
					else{	// Else if the distance to be added is less than the existing distance..
						new_entry->second.dist = temp_val;	// ...change the distance to the lesser distance then continue
						continue;
					}
				}
				// Proceeds here if the segment label does not exist in the Table_Data table, then adds a new entry
				temp.prev=curr;
				temp.dist=temp_val;
				table.insert(pair<string,Table_Data> (next_label,temp));

				prio_q.push(make_pair(temp_val,next_label));
				// Push the distance calculated to the priority queue as key, and the segment label as its element
			}
		}

		if(brk_flag==true) break;

		//Similar above but uses Node 1 as a pivot
		j = node_map.equal_range(now);
		for(auto i=j.first;i!=j.second;i++){
			temp_val=val;
			string next_label = i->second.label;

			if(next_label == end){
				cout<<"Found"<<endl;
				temp.prev=curr;
				temp.dist=temp_val;
				table.insert(pair<string,Table_Data> (next_label,temp));
				brk_flag = true;
				break;
			}

			if(!(std::find(visited.begin(), visited.end(), next_label) != visited.end())){
				temp_val+= (float)i->second.dist;
				auto new_entry = table.find(next_label);
				if(new_entry!=table.end()){
					float existing_dist = new_entry->second.dist;
					if(temp_val>=existing_dist) continue;
					else{
						new_entry->second.dist = temp_val;
						continue;
					}
				}
				temp.prev=curr;
				temp.dist=temp_val;
				table.insert(pair<string,Table_Data> (next_label,temp));

				prio_q.push(make_pair(temp_val,next_label));
			}
		}
		if(brk_flag==true) break;
		// After pushing to the priority queue and adding to the Table_Data table
		auto top = prio_q.top();	// Take the top of the priority queue/min heap as it will be the least distance
		curr=top.second;	// Copy its segment label
		val=top.first;	// Copy its value
		visited.push_back(curr);	//	Push the new current node to the visited node
		prio_q.pop();	// Remove the least distance from the priority queue
	}	//Repeat until the current node has reached the final node

	vector<string> path;	// Create a vector of strings that serves as the list of paths to take
	vector<float> dist;	// Create a vector of the distance travelled

	auto last=table.find(end);	// Create a pointer to the location of the destination node
	path.push_back(last->first);	// Push the name of the current segment label to the path, in this case the destination
	string found=last->second.prev;	// Create a copy of the name of the previous segment path it went to
	float final_dist=last->second.dist;	// Stores and tracks the distance travelled each segment

	cout<<"\nFinal Distance: "<<final_dist<<endl;
	cout<<"Total fare: "<<FareCalc(final_dist)<<endl;

	while(found!="SOURCE"){	// Work the way bay starting from the last node to the SOURCE
		path.push_back(found);	// Push the segment label to the path
		dist.push_back(final_dist);	// Push the distance travelled to the vector
		last=table.find(found);	// Find the location of the previous node
		found=last->second.prev;	// Move to the previous node
		final_dist=last->second.dist;	// Take the distance of the previous node
		if(found=="SOURCE"){
			dist.push_back(final_dist);
		}
	}

	auto v=path.rbegin();	// Creates a pointer starting from the last element of the path
	auto w=dist.rbegin();	// Creates a pointer starting from the last element of the list of distances
	cout<<"\nPath to "<<end<<":"<<endl;
	do{	// Displays the path starting from the last element to the first
		cout<<*v;	// This is due to the vector uses a queue structure, which pushes the new value to the last element
		// cout<<" \tDistance travelled: "<<*w;
		// w++;
		if(*v!=end){	// Thus if we start from the last element, we get the first segment label
			cout<<" \tDistance travelled: "<<*w;
			w++;
		}
		cout<<endl;
		v++;
	}while(v!=path.rend());
	last=table.find(end);
	cout<<"\nTotal Fare Calculation: "<<travel_speed<<" + ("<<taxi_fare<<" * "<<(int)last->second.dist<<") + ("<<fare_per_min<<" * "<<"("<<"("<<(int)last->second.dist<<" / "<<travel_speed<<")/60)"<<") "<<endl;
}

void Graph::Check(string start, string end){	// Checks the strings if it is viable for Dijkstra
	string response;	// String to store the response of the program

	bool check=false;	// Boolean to check if there is a violation

	for_each(start.begin(),start.end(),[](char & c) {
		c=tolower(c);
	});
	// Converts the start and end strings to lowercase
	for_each(end.begin(),end.end(),[](char & c){
		c=tolower(c);
	});

	// Creates a pointers to the first character of the various string
	auto s = label_map.find(start);
	auto e = label_map.find(end);

	if(s==label_map.end()){	// Checks if the starting segment label exists
		response+=start+" was not found\n";	// If it doesn't, add to the response
		check=true;	// Sets the violation to true
	}
	if(e==label_map.end()){	// Checks if the ending segment label exists
		response+=end+" was not found\n";	// If it doesn't, add to the response
		check=true;	// Sets the violation to true
	}

	if(start==end){	// Checks if the starting and ending segment both are the same
		response+="No change in desination\n";	// If it is the same, add to the response
		check=true;	// Sets the violation to true
	}

	if(check){	// Checks if there are violations
		cout<<response<<endl;	// If there is, display response then return to int main
		return;
	}

	auto strt = high_resolution_clock::now();	// Creates a timer for the Dijkstra algo
	Dijkstra(start,end);
	auto stop = high_resolution_clock::now();

	auto duration = duration_cast<microseconds>(stop - strt);
	auto seconds = duration_cast<milliseconds>(stop-strt);
  cout << "\nTime taken by Dijkstra algorithm: "<< duration.count() << " microseconds or "<<seconds.count()<<" milliseconds."<< endl;
	// Displays the time took by the function
}

void Menu(int x);

int main(){
	Graph g;
	g.Input_file();
	string x;
	string a,b;
	while(1){
		Menu(0);
		getline(cin,x);
		fflush(stdin);
		if(x=="1"){
			Menu(1);
			getline(cin,a);
			Menu(2);
			getline(cin,b);
			g.Check(a,b);
		}
		else if(x=="2") g.Disp();
		else if(x=="0"){
			cout<<"Program has been terminated."<<endl;
			return 0;
		}
		else if(x=="15") Menu(15);
		else Menu(-1);
		system("pause");
		system("cls");
	}
}

void Menu(int x){	// Function to be called for large cout
	switch(x){
		case 0:
			cout<<"Dijkstra's Algorithm Simulation"<<endl;
			cout<<"  [1] Find shortest path between two nodes"<<endl;
			cout<<"  [2] Display all segments"<<endl;
			cout<<"  [0] Exit"<<endl;
			cout<<"Choice: ";
			break;
		case 1:
			cout<<"Starting point: ";
			break;
		case 2:
			cout<<"End point: ";
			break;
		case -1:
			cout<<"Invalid input"<<endl;
			break;
		case 15:
			cout<<"Drewwwwwwwwzyyyyyyy"<<endl;
			break;
		}
}
